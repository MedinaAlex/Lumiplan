SELECT group_concat(concat(cfvo.label,'=Sep=') order by cfvo.label asc),
MAX(cf.LABEL) as label,
MAX(cf.INPUT_TYPE) as inputType
FROM CUSTOM_FIELD_VALUE cfv
JOIN CUSTOM_FIELD_BINDING cfb ON cfv.CFB_ID = cfb.CFB_ID
JOIN CUSTOM_FIELD cf ON cf.CF_ID = cfb.CF_ID
LEFT JOIN CUSTOM_FIELD_VALUE_OPTION cfvo ON cfv.CFV_ID = cfvo.CFV_ID
WHERE cfv.BOUND_ENTITY_TYPE = :entityType
AND cfv.BOUND_ENTITY_ID = :entityId
AND cfv.FIELD_TYPE = 'TAG'
GROUP BY cf.LABEL