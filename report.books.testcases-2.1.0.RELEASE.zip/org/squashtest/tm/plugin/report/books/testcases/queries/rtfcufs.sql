SELECT MAX(cfv.LARGE_VALUE) as largeValue,
MAX(cf.LABEL) as label,
MAX(cf.INPUT_TYPE) as inputType, 
cf.CF_ID as cfid 
FROM CUSTOM_FIELD_VALUE cfv 
JOIN CUSTOM_FIELD_BINDING cfb ON cfv.CFB_ID = cfb.CFB_ID 
JOIN CUSTOM_FIELD cf ON cf.CF_ID = cfb.CF_ID 
WHERE cfv.BOUND_ENTITY_TYPE = :entityType 
AND cfv.BOUND_ENTITY_ID = :entityId 
AND cfv.FIELD_TYPE = 'RTF' 
GROUP BY cfid 
ORDER BY MAX(cfb.POSITION) 
