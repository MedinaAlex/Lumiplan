-- comments
-- 
-- 1/ chain_id is now a placeholder for a data that isn't used anymore,
-- 2/ same goes for node_type
-- 3/ we test that a given node is a folder or a test case by testing if it's tc_type is null (that cannot happen for regular test cases)
-- 4/ use MAX(value) to bluff postgresql when he complains about "value must be in group by or blabla"
select 
	group_concat(concat(tcln_clos.name,'=Sep=') order by clos.depth desc) as chain,
	tcln.tcln_id as id,
	MAX((case when tc.tc_type is NULL then 1 else 0 end)) as folder,
	tcln.name as name,
	max(clos.depth) as level,
	MAX(COALESCE(tc.importance, 'UNDEFINED')) as importance,
	MAX(COALESCE(tc_nature.label, 'UNDEFINED')) as tcnature,
	MAX(COALESCE(tc_type.label, 'UNDEFINED')) as tctype,
		MAX(COALESCE(tc_nature.item_type, 'UNDEFINED')) as tcnatureType,
	MAX(COALESCE(tc_type.item_type, 'UNDEFINED')) as tctypeType,
	MAX(COALESCE(tc.tc_status, 'WORK_IN_PROGRESS')) as tcstatus,
	MAX((case when tc.ta_test is NULL then 0 else 1 end)) as execution_mode,
	MAX(COALESCE(tc.prerequisite, ' ')) as prerequisites,
	MAX(COALESCE(tc.reference, ' ')) as reference,
	tcln.created_on as created_on,
	tcln.created_by as created_by,
	tcln.last_modified_on as last_modified_on,
	tcln.last_modified_by as last_modified_by,
	tcln.description as description,
	count(attach.attachment_id) as attachments,
	group_concat(concat((case when tc_clos.tc_type is NULL then '1' else '0' end), COALESCE(tc_clos.reference, ' '), tcln_clos.name, '=Sep=') order by clos.depth desc) as sorting_key,
	case when MAX(tc.tc_type) is NULL then '' else group_concat(distinct mstones.label) end as milestones	   		   
from TCLN_RELATIONSHIP_CLOSURE clos
inner join TEST_CASE_LIBRARY_NODE tcln_clos on clos.ancestor_id=tcln_clos.tcln_id
left join TEST_CASE tc_clos on tcln_clos.tcln_id = tc_clos.tcln_id
inner join TEST_CASE_LIBRARY_NODE tcln on clos.descendant_id=tcln.tcln_id
join CUSTOM_FIELD_VALUE cfv on cfv.bound_entity_id = tc_clos.tcln_id
join CUSTOM_FIELD_VALUE_OPTION cfvo on cfvo.cfv_id = cfv.cfv_id
left join TEST_CASE tc on tcln.tcln_id = tc.tcln_id
left join MILESTONE_TEST_CASE tcstones on tc.tcln_id = tcstones.test_case_id
left join MILESTONE mstones on tcstones.milestone_id = mstones.milestone_id
left join INFO_LIST_ITEM tc_nature on tc.tc_nature = tc_nature.item_id
left join INFO_LIST_ITEM tc_type on tc.tc_type = tc_type.item_id
left join ATTACHMENT attach on attach.attachment_list_id = tcln.attachment_list_id 
where cfv.BOUND_ENTITY_TYPE = 'TEST_CASE'
and cfv.FIELD_TYPE = 'TAG'
and cfvo.LABEL in (:tags)
and (
clos.descendant_id in (select clos1.ancestor_id from TCLN_RELATIONSHIP_CLOSURE clos1 where clos1.descendant_id = :nodeId)
or clos.descendant_id in (select clos2.descendant_id from TCLN_RELATIONSHIP_CLOSURE clos2 where clos2.ancestor_id = :nodeId)
)
group by clos.descendant_id, tcln.tcln_id
order by sorting_key